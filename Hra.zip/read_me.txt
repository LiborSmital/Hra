Chůze doleva - šipka doleva
Chůze doprava - šipka doprava
Skok - mezerník
Znovu spustit hru - Esc
Ladící nástroje - l
	- vykreslování kolizí na oběktech
	- v konzoli vypis některých parametrů